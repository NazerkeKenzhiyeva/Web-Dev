export interface AlbumClass {
    userId: number,
    id: number,
    title: string
}
